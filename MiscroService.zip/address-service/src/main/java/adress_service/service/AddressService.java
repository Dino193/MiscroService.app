package adress_service.service;

import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import adress_service.entity.Address;
import adress_service.repository.AddressRepo;
import adress_service.response.AddressResponse;



@Service
public class AddressService {
	
	@Autowired
	private AddressRepo addressRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	public AddressResponse findAddressByEmployeID(int employeeID) {
		
		Address address = addressRepo.findAddressByEmployeeId(employeeID);
		
		AddressResponse addressResponse = modelMapper.map(address,AddressResponse.class);
		
		return addressResponse;
		
	}


	public List<AddressResponse> getAllAddress() {
		
		List<Address> allAddress = addressRepo.findAll();
		
		List<AddressResponse> addressList= Arrays.asList(modelMapper.map(allAddress,AddressResponse[].class));
		
		return addressList;
	}

}
