package adress_service.response;


public class AddressResponse {
	
	  private int adressID;
	  private String  lane1;
	  private String lane2;
	  private String state ;
	  private long zip;
	  
	public int getAdressID() {
		return adressID;
	}
	public void setAdressID(int adressID) {
		this.adressID = adressID;
	}
	public String getLane1() {
		return lane1;
	}
	public void setLane1(String lane1) {
		this.lane1 = lane1;
	}
	public String getLane2() {
		return lane2;
	}
	public void setLane2(String lane2) {
		this.lane2 = lane2;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getZip() {
		return zip;
	}
	public void setZip(long zip) {
		this.zip = zip;
	}

	  
	  
}
