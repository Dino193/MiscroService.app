package adress_service.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import adress_service.response.AddressResponse;
import adress_service.service.AddressService;



@RestController
public class AddressController {
	
	@Autowired
	private AddressService addresService;
	
	
	
	@GetMapping("/address")
	public ResponseEntity<List<AddressResponse>> getAllAddress() {

	    List<AddressResponse> addressResponse = addresService.getAllAddress();

	    return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
	}
	
	
	
	@GetMapping("/address/{employeeID}")
	public ResponseEntity<AddressResponse> getAddressByEmployeeId(@PathVariable("employeeID") int employeeID) {
		
		AddressResponse addressResponse = null;
		
		addressResponse = addresService.findAddressByEmployeID(employeeID);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
		
		
	
	    
    }
	
	/*@GetMapping("/address")
	public String getAddress() {
		
		return "lake road,Belgrade,Serbia";
	}*/

}
