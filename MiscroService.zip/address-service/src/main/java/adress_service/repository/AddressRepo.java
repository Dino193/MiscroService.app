package adress_service.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import adress_service.entity.Address;

public interface AddressRepo  extends JpaRepository<Address,Integer>{
	
	

	@Query(nativeQuery = true, value = "SELECT * FROM adress a WHERE a.employeeID = :employeeID")
	Address findAddressByEmployeeId(@Param("employeeID")int employeeID);
	
	

}
