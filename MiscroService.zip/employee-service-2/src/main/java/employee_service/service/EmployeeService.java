package employee_service.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import employee_service.entity.Employee;
import employee_service.feignclient.AddressClient;
import employee_service.repository.EmployeeRepo;
import employee_service.response.AddressResponse;
import employee_service.response.EmployeeResponse;


@Service
public class EmployeeService {
	
	
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	@Autowired
	private AddressClient addressClient;
	


	public  EmployeeResponse getEmployeeById(int employeeID) {
		
		
		Employee employee = employeeRepo.findById(employeeID).get();
		
		EmployeeResponse employeeResponse = modelMapper.map(employee,EmployeeResponse.class);
		
	     
		ResponseEntity<AddressResponse> addressResponseEntity = addressClient.getAddressByEmployeeId(employeeID);
		AddressResponse addressResponse = addressResponseEntity.getBody();
		
		employeeResponse.setAddressResponse(addressResponse);
		
		return employeeResponse ;
	
	}
	
	/*public  EmployeeResponse getEmployeeById(int employeeID) {
		
		
		Employee employee = employeeRepo.findById(employeeID).get();
		
		
	    EmployeeResponse  employeeResponse = new  EmployeeResponse ();
	    employeeResponse.setEmployeeID(employee.getEmployeeID());
	    employeeResponse.setName(employee.getName());
	    employeeResponse.setEmail(employee.getEmail());
	    employeeResponse.setBloodgroup(employee.getBloodgroup());
		
		return employeeResponse ;
		
	}
*/
	
	
}
