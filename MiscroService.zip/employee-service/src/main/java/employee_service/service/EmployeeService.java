package employee_service.service;

import java.util.Arrays;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import employee_service.entity.Employee;
import employee_service.openfeignclients.AddressClient;
import employee_service.repository.EmployeeRepo;
import employee_service.response.AddressResponse;
import employee_service.response.EmployeeResponse;


@Service
public class EmployeeService {
	
	
	
	@Autowired
	private EmployeeRepo employeeRepo;
	
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	@Autowired
	private WebClient webClient;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AddressClient addressClient;
	
	//@Autowired
	//private DiscoveryClient discoveryClient;
	
	
	//@Autowired
	//private LoadBalancerClient loadBalancerClient;
    
/*
	public  EmployeeResponse getEmployeeById(int employeeID) {
		
		
		Employee employee = employeeRepo.findById(employeeID).get();
		
		EmployeeResponse employeeResponse = modelMapper.map(employee,EmployeeResponse.class);
		
	     
		 AddressResponse addressResponse = callToAddressServiceUsingWebClient(employeeID);
		
		employeeResponse.setAddressResponse(addressResponse);
		
		return employeeResponse ;
	
	}*/
	
	
	public List<EmployeeResponse> getAllEmployees() {

	   
	    List<Employee> employeeList = employeeRepo.findAll();

	    // Map the Employee entities to EmployeeResponse objects
	    List<EmployeeResponse> employeesResponse = Arrays.asList(modelMapper.map(employeeList, EmployeeResponse[].class));

	    ResponseEntity<List<AddressResponse>> allAddress = addressClient.getAllAddress();
	    List<AddressResponse>addressResponse=allAddress.getBody();
	    
	    employeesResponse.forEach(employee -> {
	       
	    	for(AddressResponse addrResponse : addressResponse) {
	    		
	    		if(addrResponse.getAdressID() == employee.getEmployeeID()) {
	    			
	    	    	
	        employee.setAddressResponse(addrResponse);
	        
	    		}
	    	}
	    });

	    return employeesResponse;
	}

	
  public  EmployeeResponse getEmployeeById(int employeeID) {
		
		
		Employee employee = employeeRepo.findById(employeeID).get();
		
		
	    EmployeeResponse  employeeResponse = modelMapper.map(employee,EmployeeResponse.class);
	    
	    
	    ResponseEntity<AddressResponse> addressResponseEntity = addressClient.getAddressByEmployeeId(employeeID);
	    AddressResponse addressResponse = addressResponseEntity.getBody();
	    
	    employeeResponse.setAddressResponse(addressResponse);
	    
		
	    return employeeResponse ;
		
	}
	
	private AddressResponse callToAddressServiceUsingWebClient(int employeeID) {
		                
		               return webClient
				
				           .get()
				           .uri("/address"+employeeID)
				           .retrieve()
				           .bodyToMono(AddressResponse.class)
				           .block();
	}
	
	
	
	private AddressResponse callToAddressServiceUsingRESTTemplate(int employeeID) {
	    
		
	    
   return restTemplate.getForObject("http://address-service/address-app/api/address/{employeeID}", AddressResponse.class, employeeID);
	    
	}


	
	
	/*
       private AddressResponse callToAddressServiceUsingRESTTemplate(int employeeID) {
		
	    
    	 ServiceInstance serviceInstance = loadBalancerClient.choose("address-service");
	     String uri = serviceInstance.getUri().toString();
	     String contextRoot = serviceInstance.getMetadata().get("configPath");
		
	     
		return restTemplate.getForObject(uri+contextRoot+"/address{employeeID}",AddressResponse.class);
	}
   */    
	
	/*private AddressResponse callToAddressServiceUsingRESTTemplate(int employeeID) {
		
		//dinamicko dobijanje instance iz servera u ovom slucaju addrese
        List<ServiceInstance>instances = discoveryClient.getInstances("address-service");
		ServiceInstance serviceInstance = instances.get(0);
		
		String uri = serviceInstance.getUri().toString();
		
		return restTemplate.getForObject(uri+"/address-app/api/address{employeeID}",AddressResponse.class);
	}
	*/

    }

	

