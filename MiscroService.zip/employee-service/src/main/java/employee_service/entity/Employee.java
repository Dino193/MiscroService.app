package employee_service.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employeeID;
	
	@Column(name="name")
	private String name;
	
	@Column(name="email")
    private String email;
    
	@Column(name="bloodgroup")
    private String bloodgroup;

	
	
	public Employee() {
		
	}



	public Employee(String name, String email, String bloodgroup) {
		super();
		this.name = name;
		this.email = email;
		this.bloodgroup = bloodgroup;
	}



	public int getEmployeeID() {
		return employeeID;
	}



	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getBloodgroup() {
		return bloodgroup;
	}



	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}



	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", name=" + name + ", email=" + email + ", bloodgroup="
				+ bloodgroup + "]";
	}
	
	
	

	
	
	

}
